package com.voleyclips.app

import android.content.Context
import android.media.MediaMetadataRetriever
import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs

/** Cada cuántos milisegundos se mira un cuadro del video. */
const val SCAN_STEP_MS = 300L

/** Tiempos (ms del video) en que alguien empezó a hacer cada gesto. */
data class ScanResult(
    val clipTimesMs: List<Long>, // ✊ puño: jugada
    val pointsA: List<Long>,     // 👍 punto equipo A
    val pointsB: List<Long>,     // ✌ punto equipo B
)

/**
 * De una lista de (tiempo, gesto) saca los gestos hechos de verdad: el mismo gesto visto en al menos [minHits]
 * muestras dentro de [windowMs]. Devuelve (tiempo en que empezó, nombre). Después de cada uno espera [cooldownMs].
 */
fun findGestureEvents(
    samples: List<Pair<Long, String>>,
    windowMs: Long = 1500L,
    minHits: Int = 3,
    cooldownMs: Long = 4000L,
): List<Pair<Long, String>> {
    val events = mutableListOf<Pair<Long, String>>()
    var cooldownUntil = Long.MIN_VALUE
    for (i in samples.indices) {
        val (t, name) = samples[i]
        if (name.isEmpty() || t < cooldownUntil) continue
        var hits = 0
        var first = t
        var j = i
        while (j >= 0 && t - samples[j].first <= windowMs) {
            if (samples[j].second == name) {
                hits++
                first = samples[j].first
            }
            j--
        }
        if (hits >= minHits) {
            events.add(first to name)
            cooldownUntil = t + cooldownMs
        }
    }
    return events
}

/**
 * Recorre el video mirando un cuadro cada [SCAN_STEP_MS] y busca los gestos.
 * [onProgress] recibe el avance (0 a 1) y los minutos que faltan más o menos.
 * Devuelve null si no se pudo analizar. Se puede cancelar cancelando la corrutina.
 */
suspend fun scanVideo(
    ctx: Context,
    file: File,
    onProgress: (Float, Int) -> Unit,
): ScanResult? = withContext(Dispatchers.Default) {
    val scanner = GestureScanner(ctx)
    if (scanner.start() != null) return@withContext null
    val r = MediaMetadataRetriever()
    try {
        r.setDataSource(file.absolutePath)
        val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        if (dur <= 0L) return@withContext null
        val ratio = Store.ratioOf(file)
        val w = 480
        val h = maxOf(2, (w / ratio).toInt())
        val samples = ArrayList<Pair<Long, String>>()
        val started = SystemClock.elapsedRealtime()
        var t = 0L
        var n = 0
        while (t < dur) {
            ensureActive()
            val bmp = try {
                r.getScaledFrameAtTime(t * 1000L, MediaMetadataRetriever.OPTION_CLOSEST, w, h)
            } catch (e: Exception) {
                null
            }
            if (bmp != null) samples.add(t to scanner.classify(bmp))
            t += SCAN_STEP_MS
            n++
            if (n % 10 == 0) {
                val done = (t.toFloat() / dur).coerceIn(0f, 1f)
                val perSampleMs = (SystemClock.elapsedRealtime() - started).toFloat() / n
                val left = ((dur - t) / SCAN_STEP_MS * perSampleMs / 60000f).toInt()
                onProgress(done, left)
            }
        }
        onProgress(1f, 0)
        val events = findGestureEvents(samples)
        ScanResult(
            clipTimesMs = events.filter { it.second == "Closed_Fist" }.map { it.first },
            pointsA = events.filter { it.second == "Thumb_Up" }.map { it.first },
            pointsB = events.filter { it.second == "Victory" }.map { it.first },
        )
    } finally {
        r.release()
        scanner.close()
    }
}

/**
 * Aplica lo que encontró el análisis. Agrega las jugadas que todavía no estaban (a menos de 6 s de otra)
 * y, si [recalc] es true, rearma el marcador con los gestos de punto y se lo pone a cada jugada.
 * Devuelve la lista de jugadas, el marcador final, y cuántas jugadas se agregaron.
 */
fun applyScan(m: Match, clips: List<Clip>, res: ScanResult, recalc: Boolean): Triple<List<Clip>, String, Int> {
    val all = clips.toMutableList()
    var added = 0
    for (t0 in res.clipTimesMs) {
        val tMs = maxOf(1000L, t0 - 400L) // la jugada termina un instante antes del gesto
        if (all.none { abs(it.tMs - tMs) < 6000L }) {
            all.add(Clip(id = System.nanoTime() + added, tMs = tMs, preMs = 29000L, postMs = 1000L, tag = "Punto", zoom = 1f))
            added++
        }
    }
    var finalText = m.finalScore
    var timeline = emptyList<Pair<Long, Score>>()
    if (recalc) {
        val events = (res.pointsA.map { it to 1 } + res.pointsB.map { it to 2 }).sortedBy { it.first }
        var s = Score()
        val tl = ArrayList<Pair<Long, Score>>()
        for ((t, team) in events) {
            s = addPoint(s, team, m.mode, m.parkTarget)
            tl.add(t to s)
        }
        finalText = finalScoreText(s, m.teamA, m.teamB)
        timeline = tl
    }
    val result = all.sortedBy { it.tMs }.map { c ->
        if (recalc) c.copy(score = scoreLabel(timeline.lastOrNull { it.first <= c.tMs }?.second ?: Score())) else c
    }
    return Triple(result, finalText, added)
}
