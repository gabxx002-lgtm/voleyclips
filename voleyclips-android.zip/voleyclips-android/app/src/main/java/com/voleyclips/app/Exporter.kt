package com.voleyclips.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.OverlayEffect
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.google.common.collect.ImmutableList
import java.io.File

/**
 * Recorta cada jugada del video completo, le mete el zoom al punto y las une en un solo archivo.
 * Todo pasa dentro del celular con Media3 Transformer.
 */
object Exporter {

    /** Ancho y alto del video como se ve (con la rotación aplicada). */
    private fun displaySize(file: File): Pair<Int, Int> {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(file.absolutePath)
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1280
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 720
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) h to w else w to h
        } catch (e: Exception) {
            1280 to 720
        } finally {
            r.release()
        }
    }

    /**
     * Marca de agua de Vortix: una imagen transparente del tamaño del video con el logo
     * chiquito en la esquina inferior derecha.
     */
    private fun makeWatermark(ctx: Context, w: Int, h: Int): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val logo = BitmapFactory.decodeResource(ctx.resources, R.drawable.vortix_watermark) ?: return out
        val side = minOf(w, h)
        val size = (side * 0.14f).toInt().coerceAtLeast(40)
        val margin = (side * 0.03f).toInt()
        val scaled = Bitmap.createScaledBitmap(logo, size, size, true)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply { alpha = 220 }
        Canvas(out).drawBitmap(scaled, (w - size - margin).toFloat(), (h - size - margin).toFloat(), paint)
        return out
    }

    fun buildComposition(ctx: Context, videoFile: File, clips: List<Clip>, durationMs: Long): Composition {
        val videoUri = Uri.fromFile(videoFile)
        val (vw, vh) = displaySize(videoFile)
        val watermark = OverlayEffect(ImmutableList.of(BitmapOverlay.createStaticBitmapOverlay(makeWatermark(ctx, vw, vh))))
        val items = clips.map { c ->
            val startMs = clipStart(c)
            val endMs = clipEnd(c, durationMs)
            val mediaItem = MediaItem.Builder()
                .setUri(videoUri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(startMs)
                        .setEndPositionMs(endMs)
                        .build()
                )
                .build()

            val zoomEffect: Effect? = if (c.zoom > 1f) {
                val markOffsetMs = (c.tMs - startMs).toFloat()
                var firstUs = -1L
                MatrixTransformation { presentationTimeUs ->
                    // El tiempo se mide desde el primer cuadro de esta jugada.
                    if (firstUs < 0L) firstUs = presentationTimeUs
                    val sinceStartMs = (presentationTimeUs - firstUs) / 1000f
                    val s = zoomFactor(c.zoom, sinceStartMs - markOffsetMs)
                    val half = 1f - 1f / s
                    // Coordenadas normalizadas del GL: x a la derecha, y hacia arriba, de -1 a 1.
                    val px = (2f * c.fx - 1f).coerceIn(-half, half)
                    val py = (1f - 2f * c.fy).coerceIn(-half, half)
                    Matrix().apply {
                        postTranslate(-px, -py)
                        postScale(s, s)
                    }
                }
            } else {
                null
            }
            // Primero el zoom y al final la marca de agua, para que la marca no se agrande con el zoom.
            val effects = Effects(emptyList<AudioProcessor>(), listOfNotNull(zoomEffect, watermark))
            EditedMediaItem.Builder(mediaItem).setEffects(effects).build()
        }
        return Composition.Builder(EditedMediaItemSequence(items)).build()
    }

    fun start(
        ctx: Context,
        composition: Composition,
        out: File,
        onDone: () -> Unit,
        onError: (String) -> Unit,
    ): Transformer {
        val encoderFactory = DefaultEncoderFactory.Builder(ctx)
            .setRequestedVideoEncoderSettings(
                VideoEncoderSettings.Builder().setBitrate(6_000_000).build()
            )
            .build()
        val transformer = Transformer.Builder(ctx)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(encoderFactory)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    onDone()
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException,
                ) {
                    onError(exportException.message ?: "No se pudo armar el video.")
                }
            })
            .build()
        transformer.start(composition, out.absolutePath)
        return transformer
    }

    /** Copia el video a la galería (Movies/Vortix). No pide permisos en Android 10 o más. */
    fun saveToGallery(ctx: Context, file: File, displayName: String): Boolean {
        val resolver = ctx.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Vortix")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        return try {
            resolver.openOutputStream(uri)?.use { out ->
                file.inputStream().use { it.copyTo(out) }
            } ?: return false
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            true
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            false
        }
    }
}
