package com.voleyclips.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import androidx.camera.core.ImageProxy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizer
import com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizerResult
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer

/** Modelo oficial de MediaPipe para reconocer gestos de mano (unos 8 MB). Se baja una sola vez. */
const val GESTURE_MODEL_URL =
    "https://storage.googleapis.com/mediapipe-models/gesture_recognizer/gesture_recognizer/float16/latest/gesture_recognizer.task"

/** Códigos que devuelve el vigilante: 30 = guardar jugada de 30 s, y estos dos para los puntos. */
const val GESTURE_POINT_A = 101 // 👍 pulgar arriba: punto para el equipo A
const val GESTURE_POINT_B = 102 // ✌ paz (dos dedos): punto para el equipo B

object GestureModel {
    fun file(ctx: Context) = File(ctx.filesDir, "gesture_recognizer.task")

    fun isReady(ctx: Context): Boolean = file(ctx).let { it.exists() && it.length() > 1_000_000L }

    /** Descarga el modelo. Devuelve null si salió bien, o un mensaje con lo que falló. */
    fun download(ctx: Context): String? {
        val tmp = File(ctx.filesDir, "gesture_recognizer.task.part")
        try {
            val conn = URL(GESTURE_MODEL_URL).openConnection() as HttpURLConnection
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            if (conn.responseCode !in 200..299) return "el servidor respondió " + conn.responseCode
            conn.inputStream.use { input -> tmp.outputStream().use { out -> input.copyTo(out) } }
            if (tmp.length() < 1_000_000L) {
                tmp.delete()
                return "el archivo del modelo llegó incompleto"
            }
            if (!tmp.renameTo(file(ctx))) return "no pude guardar el modelo"
            return null
        } catch (e: Exception) {
            tmp.delete()
            return e.message ?: "no hay internet"
        }
    }
}

/**
 * Mira la cámara y avisa cuando alguien sostiene un gesto de mano frente al lente:
 * ✊ = guardar jugada de 30 s, 👍 = punto equipo A, ✌ = punto equipo B. Hay que sostenerlo cerca de 1 s para evitar falsas alarmas.
 */
class GestureWatcher(
    private val ctx: Context,
    private val onGesture: (Int) -> Unit,
) {
    private var recognizer: GestureRecognizer? = null
    private var lastName = ""
    private var streak = 0
    private var cooldownUntil = 0L
    private var lastFrameAt = 0L

    @Volatile
    private var closed = false

    /** Devuelve null si quedó listo, o un mensaje con el motivo. */
    fun start(): String? {
        return try {
            val bytes = GestureModel.file(ctx).readBytes()
            val buf = ByteBuffer.allocateDirect(bytes.size)
            buf.put(bytes)
            buf.rewind()
            val base = BaseOptions.builder().setModelAssetBuffer(buf).build()
            val options = GestureRecognizer.GestureRecognizerOptions.builder()
                .setBaseOptions(base)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumHands(1)
                .setMinHandDetectionConfidence(0.6f)
                .setMinHandPresenceConfidence(0.6f)
                .setMinTrackingConfidence(0.6f)
                .setResultListener { result, _ -> handle(result) }
                .setErrorListener { _ -> }
                .build()
            recognizer = GestureRecognizer.createFromOptions(ctx, options)
            null
        } catch (e: Exception) {
            e.message ?: "no se pudo iniciar el reconocimiento de gestos"
        }
    }

    private fun handle(result: GestureRecognizerResult) {
        val top = result.gestures().firstOrNull()?.firstOrNull()
        val lm = result.landmarks().firstOrNull()
        // El pulgar arriba se revisa también por la posición de los dedos, así vale de frente o de espaldas.
        // Los demás gestos solo cuentan si la cámara está bastante segura.
        val name = when {
            lm != null && isThumbsUp(lm) -> "Thumb_Up"
            top != null && top.score() >= MIN_SCORE -> top.categoryName()
            else -> ""
        }
        val secs = when (name) {
            "Closed_Fist" -> 30            // ✊ puño: guarda la jugada (30 s)
            "Thumb_Up" -> GESTURE_POINT_A  // 👍 pulgar arriba: punto equipo A
            "Victory" -> GESTURE_POINT_B   // ✌ paz: punto equipo B
            else -> 0
        }
        if (secs == 0) {
            streak = 0
        } else if (name == lastName) {
            streak++
        } else {
            streak = 1
        }
        lastName = name
        val now = SystemClock.elapsedRealtime()
        if (secs != 0 && streak >= HOLD_FRAMES && now >= cooldownUntil) {
            cooldownUntil = now + COOLDOWN_MS
            streak = 0
            onGesture(secs)
        }
    }

    @Volatile
    private var aspect = 4f / 3f // ancho / alto de la imagen que se analiza

    /**
     * Pulgar arriba por geometría: cuatro dedos doblados y el pulgar estirado, claramente por encima de ellos.
     * No importa si la cámara ve la palma o el dorso de la mano.
     */
    private fun isThumbsUp(lm: List<NormalizedLandmark>): Boolean {
        if (lm.size < 21) return false
        val a = aspect
        fun d(i: Int, j: Int): Float {
            val dx = (lm[i].x() - lm[j].x()) * a
            val dy = lm[i].y() - lm[j].y()
            return kotlin.math.sqrt(dx * dx + dy * dy)
        }
        val size = d(0, 9) // muñeca a nudillo del medio
        if (size < 0.03f) return false
        val curled = listOf(8 to 5, 12 to 9, 16 to 13, 20 to 17).all { (tip, mcp) -> d(tip, 0) <= d(mcp, 0) * 1.25f }
        if (!curled) return false
        val highestOther = minOf(lm[8].y(), lm[12].y(), lm[16].y(), lm[20].y())
        val thumbUp = lm[4].y() < highestOther - 0.35f * size && lm[4].y() < lm[3].y() && lm[3].y() < lm[2].y()
        return thumbUp && d(4, 2) > 0.6f * size
    }

    /** Se llama con cada imagen del ImageAnalysis de CameraX. Siempre cierra la imagen. */
    fun analyze(image: ImageProxy) {
        try {
            val rec = recognizer
            val now = SystemClock.elapsedRealtime()
            if (rec == null || closed || now - lastFrameAt < FRAME_GAP_MS) return
            lastFrameAt = now
            val bmp = image.toBitmap()
            val rot = image.imageInfo.rotationDegrees
            val upright = if (rot != 0) {
                Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot.toFloat()) }, true)
            } else {
                bmp
            }
            aspect = upright.width.toFloat() / upright.height
            rec.recognizeAsync(BitmapImageBuilder(upright).build(), SystemClock.uptimeMillis())
        } catch (e: Exception) {
            // un cuadro perdido no importa
        } finally {
            image.close()
        }
    }

    fun close() {
        closed = true
        try {
            recognizer?.close()
        } catch (e: Exception) {
            // ya estaba cerrado
        }
        recognizer = null
    }

    companion object {
        const val MIN_SCORE = 0.8f     // seguridad mínima de la cámara para aceptar un gesto
        const val HOLD_FRAMES = 5     // 1 s seguido con el gesto firme (a 5 cuadros por segundo)
        const val COOLDOWN_MS = 4_000L // después de guardar una jugada, espera antes de aceptar otro gesto
        const val FRAME_GAP_MS = 200L  // 5 cuadros por segundo alcanzan y dejan al celular libre para grabar fluido
    }
}
