package com.voleyclips.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import androidx.camera.core.ImageProxy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizer
import com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizerResult
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer

/** Modelo oficial de MediaPipe para reconocer gestos de mano (unos 8 MB). Se baja una sola vez. */
const val GESTURE_MODEL_URL =
    "https://storage.googleapis.com/mediapipe-models/gesture_recognizer/gesture_recognizer/float16/latest/gesture_recognizer.task"

/** Códigos de acción: 30 = guardar jugada de 30 s, y estos dos para los puntos. */
const val GESTURE_POINT_A = 101 // 👍 pulgar arriba: punto para el equipo A
const val GESTURE_POINT_B = 102 // ✌ paz (dos dedos): punto para el equipo B

object GestureModel {
    fun file(ctx: Context) = File(ctx.filesDir, "gesture_recognizer.task")

    fun isReady(ctx: Context): Boolean = file(ctx).let { it.exists() && it.length() > 1_000_000L }

    /** Descarga el modelo. Devuelve null si salió bien, o un mensaje con lo que falló. */
    fun download(ctx: Context): String? {
        val tmp = File(ctx.filesDir, "gesture_recognizer.task.part")
        try {
            val conn = URL(GESTURE_MODEL_URL).openConnection() as HttpURLConnection
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            if (conn.responseCode !in 200..299) return "el servidor respondió " + conn.responseCode
            conn.inputStream.use { input -> tmp.outputStream().use { out -> input.copyTo(out) } }
            if (tmp.length() < 1_000_000L) {
                tmp.delete()
                return "el archivo del modelo llegó incompleto"
            }
            if (!tmp.renameTo(file(ctx))) return "no pude guardar el modelo"
            return null
        } catch (e: Exception) {
            tmp.delete()
            return e.message ?: "no hay internet"
        }
    }

    fun buffer(ctx: Context): ByteBuffer {
        val bytes = file(ctx).readBytes()
        val buf = ByteBuffer.allocateDirect(bytes.size)
        buf.put(bytes)
        buf.rewind()
        return buf
    }
}

/* ---------------- Forma de la mano (no depende de si se ve la palma o el dorso) ---------------- */

private fun dist(lm: List<NormalizedLandmark>, i: Int, j: Int, aspect: Float): Float {
    val dx = (lm[i].x() - lm[j].x()) * aspect
    val dy = lm[i].y() - lm[j].y()
    return kotlin.math.sqrt(dx * dx + dy * dy)
}

/** Cuatro dedos doblados: la punta de cada uno queda cerca de la muñeca. */
private fun fingersCurled(lm: List<NormalizedLandmark>, aspect: Float): Boolean =
    listOf(8 to 5, 12 to 9, 16 to 13, 20 to 17).all { (tip, mcp) ->
        dist(lm, tip, 0, aspect) <= dist(lm, mcp, 0, aspect) * 1.25f
    }

/** Pulgar arriba: dedos doblados y el pulgar estirado, claramente por encima de ellos. */
fun isThumbsUp(lm: List<NormalizedLandmark>, aspect: Float): Boolean {
    if (lm.size < 21) return false
    val size = dist(lm, 0, 9, aspect) // muñeca a nudillo del medio
    if (size < 0.03f || !fingersCurled(lm, aspect)) return false
    val highestOther = minOf(lm[8].y(), lm[12].y(), lm[16].y(), lm[20].y())
    val up = lm[4].y() < highestOther - 0.35f * size && lm[4].y() < lm[3].y() && lm[3].y() < lm[2].y()
    return up && dist(lm, 4, 2, aspect) > 0.6f * size
}

/** Puño: dedos doblados y el pulgar recogido sobre ellos (no estirado hacia arriba). */
fun isFist(lm: List<NormalizedLandmark>, aspect: Float): Boolean {
    if (lm.size < 21) return false
    val size = dist(lm, 0, 9, aspect)
    if (size < 0.03f || !fingersCurled(lm, aspect)) return false
    if (isThumbsUp(lm, aspect)) return false
    return dist(lm, 4, 5, aspect) < 1.0f * size
}

/** Nombre del gesto (de MediaPipe) o "" si no hay ninguno que nos sirva. */
fun classifyHand(result: GestureRecognizerResult, aspect: Float, minScore: Float): String {
    val lm = result.landmarks().firstOrNull()
    val top = result.gestures().firstOrNull()?.firstOrNull()
    return when {
        lm != null && isThumbsUp(lm, aspect) -> "Thumb_Up"
        lm != null && isFist(lm, aspect) -> "Closed_Fist"
        top != null && top.score() >= minScore -> top.categoryName()
        else -> ""
    }
}

/** De nombre de gesto a acción: 30 (jugada), 101 (punto A), 102 (punto B) o 0 si no hace nada. */
fun gestureCode(name: String): Int = when (name) {
    "Closed_Fist" -> 30            // ✊ puño: guarda la jugada (30 s)
    "Thumb_Up" -> GESTURE_POINT_A  // 👍 pulgar arriba: punto equipo A
    "Victory" -> GESTURE_POINT_B   // ✌ paz: punto equipo B
    else -> 0
}

/**
 * Mira la cámara en vivo y avisa cuando alguien hace un gesto frente al lente:
 * ✊ = guardar jugada de 30 s, 👍 = punto equipo A, ✌ = punto equipo B.
 * Basta con ver el gesto en unos 3 cuadros dentro de un segundo y medio; no hace falta que sean seguidos.
 */
class GestureWatcher(
    private val ctx: Context,
    private val onGesture: (Int) -> Unit,
) {
    private var recognizer: GestureRecognizer? = null
    private val recent = ArrayDeque<Pair<Long, String>>()
    private var cooldownUntil = 0L
    private var lastFrameAt = 0L

    @Volatile
    private var aspect = 4f / 3f // ancho / alto de la imagen que se analiza

    @Volatile
    private var closed = false

    /** Devuelve null si quedó listo, o un mensaje con el motivo. */
    fun start(): String? {
        return try {
            val base = BaseOptions.builder().setModelAssetBuffer(GestureModel.buffer(ctx)).build()
            val options = GestureRecognizer.GestureRecognizerOptions.builder()
                .setBaseOptions(base)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumHands(1)
                .setMinHandDetectionConfidence(0.5f)
                .setMinHandPresenceConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .setResultListener { result, _ -> handle(result) }
                .setErrorListener { _ -> }
                .build()
            recognizer = GestureRecognizer.createFromOptions(ctx, options)
            null
        } catch (e: Exception) {
            e.message ?: "no se pudo iniciar el reconocimiento de gestos"
        }
    }

    private fun handle(result: GestureRecognizerResult) {
        val now = SystemClock.elapsedRealtime()
        val name = classifyHand(result, aspect, MIN_SCORE)
        val code = gestureCode(name)
        while (recent.isNotEmpty() && now - recent.first().first > WINDOW_MS) recent.removeFirst()
        if (code == 0) return
        recent.addLast(now to name)
        if (now < cooldownUntil) return
        val hits = recent.count { it.second == name }
        if (hits >= HOLD_HITS) {
            cooldownUntil = now + COOLDOWN_MS
            recent.clear()
            onGesture(code)
        }
    }

    /** Se llama con cada imagen del ImageAnalysis de CameraX. Siempre cierra la imagen. */
    fun analyze(image: ImageProxy) {
        try {
            val rec = recognizer
            val now = SystemClock.elapsedRealtime()
            if (rec == null || closed || now - lastFrameAt < FRAME_GAP_MS) return
            lastFrameAt = now
            val bmp = image.toBitmap()
            val rot = image.imageInfo.rotationDegrees
            val upright = if (rot != 0) {
                Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot.toFloat()) }, true)
            } else {
                bmp
            }
            aspect = upright.width.toFloat() / upright.height
            rec.recognizeAsync(BitmapImageBuilder(upright).build(), SystemClock.uptimeMillis())
        } catch (e: Exception) {
            // un cuadro perdido no importa
        } finally {
            image.close()
        }
    }

    fun close() {
        closed = true
        try {
            recognizer?.close()
        } catch (e: Exception) {
            // ya estaba cerrado
        }
        recognizer = null
    }

    companion object {
        const val MIN_SCORE = 0.6f     // seguridad mínima de la cámara para aceptar un gesto
        const val WINDOW_MS = 1500L    // el gesto se busca en este lapso...
        const val HOLD_HITS = 3        // ...y hay que verlo en al menos estos cuadros
        const val COOLDOWN_MS = 3500L  // después de aceptar un gesto, espera antes de aceptar otro
        const val FRAME_GAP_MS = 140L  // unos 7 cuadros por segundo
    }
}

/** Lo mismo pero sobre imágenes sueltas (para analizar un video ya grabado). */
class GestureScanner(private val ctx: Context) {
    private var recognizer: GestureRecognizer? = null

    fun start(): String? {
        return try {
            val base = BaseOptions.builder().setModelAssetBuffer(GestureModel.buffer(ctx)).build()
            val options = GestureRecognizer.GestureRecognizerOptions.builder()
                .setBaseOptions(base)
                .setRunningMode(RunningMode.IMAGE)
                .setNumHands(1)
                .setMinHandDetectionConfidence(0.4f)
                .setMinHandPresenceConfidence(0.4f)
                .setMinTrackingConfidence(0.4f)
                .build()
            recognizer = GestureRecognizer.createFromOptions(ctx, options)
            null
        } catch (e: Exception) {
            e.message ?: "no se pudo iniciar el reconocimiento de gestos"
        }
    }

    /** Nombre del gesto que se ve en la imagen, o "". */
    fun classify(bmp: Bitmap): String {
        val rec = recognizer ?: return ""
        return try {
            val argb = if (bmp.config == Bitmap.Config.ARGB_8888) bmp else bmp.copy(Bitmap.Config.ARGB_8888, false)
            val res = rec.recognize(BitmapImageBuilder(argb).build())
            classifyHand(res, argb.width.toFloat() / argb.height, 0.55f)
        } catch (e: Exception) {
            ""
        }
    }

    fun close() {
        try {
            recognizer?.close()
        } catch (e: Exception) {
            // ya estaba cerrado
        }
        recognizer = null
    }
}
