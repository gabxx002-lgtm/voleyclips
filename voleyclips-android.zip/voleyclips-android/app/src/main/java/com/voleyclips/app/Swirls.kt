package com.voleyclips.app

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.paint
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp

/** Fondo de remolinos (sacado del logo), muy suave, que se dibuja detrás del contenido. */
@Composable
fun Modifier.swirlBackdrop(alpha: Float = 0.06f, alignment: Alignment = Alignment.BottomEnd): Modifier =
    this.paint(
        painter = painterResource(R.drawable.vortix_swirls),
        sizeToIntrinsics = false,
        alignment = alignment,
        contentScale = ContentScale.Crop,
        alpha = alpha,
    )

/** Línea con un rizo en el centro para separar secciones. */
@Composable
fun SwirlDivider(modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .weight(1f)
                .height(2.dp)
                .background(VcInk, RoundedCornerShape(1.dp))
        )
        Image(
            painter = painterResource(R.drawable.vortix_curl),
            contentDescription = null,
            modifier = Modifier
                .padding(horizontal = 8.dp)
                .size(30.dp),
        )
        Box(
            Modifier
                .weight(1f)
                .height(2.dp)
                .background(VcInk, RoundedCornerShape(1.dp))
        )
    }
}
