package com.voleyclips.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Estética Vortix: tinta negra sobre blanco. El único color es el rojo de "grabando".
val VcInk = Color(0xFF111111)
val VcPaper = Color(0xFFFFFFFF)
val VcAccent = Color(0xFFFFFFFF)   // blanco para dibujar encima del video
val VcOnAccent = Color(0xFF111111)
val VcRed = Color(0xFFD7263D)      // grabando

val VoleyLightScheme = lightColorScheme(
    primary = VcInk,
    onPrimary = VcPaper,
    secondary = Color(0xFF1A1A1A),
    onSecondary = VcPaper,
    secondaryContainer = VcInk,
    onSecondaryContainer = VcPaper,
    background = VcPaper,
    onBackground = VcInk,
    surface = Color(0xFFF3F3F3),
    onSurface = VcInk,
    surfaceVariant = Color(0xFFE6E6E6),
    onSurfaceVariant = Color(0xFF555555),
    outline = Color(0xFF8A8A8A),
    error = Color(0xFFB3261E),
)

/** Para los paneles que van encima del video al grabar. */
val VoleyDarkScheme = darkColorScheme(
    primary = VcPaper,
    onPrimary = VcInk,
    secondary = VcPaper,
    onSecondary = VcInk,
    secondaryContainer = VcPaper,
    onSecondaryContainer = VcInk,
    background = VcInk,
    onBackground = VcPaper,
    surface = Color(0xFF1C1C1C),
    onSurface = VcPaper,
    surfaceVariant = Color(0xFF2B2B2B),
    onSurfaceVariant = Color(0xFFBBBBBB),
    outline = Color(0xFF9A9A9A),
    error = Color(0xFFFF6B7F),
)

@Composable
fun VoleyTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = VoleyLightScheme, content = content)
}
